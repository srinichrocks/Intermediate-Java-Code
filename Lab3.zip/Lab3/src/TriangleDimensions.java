//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The superclass TriangleDimensions which has area and surface area
//computing methods
public abstract class TriangleDimensions {
    double side = 0.0;
    double area = 0.0;
    double surfaceArea = 0.0;
    String shape = "Triangle";

    public abstract void computeArea();
    public abstract void computeSurfaceArea();
    public TriangleDimensions(double side) {
        this.side = side;
    }
}
