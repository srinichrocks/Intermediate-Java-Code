//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The driver class which displays using gui the area of triangle and
//surface area of triangular pyramid
import javax.swing.*;


public class TriangleAreaApp {

    public static void main(String[] args) {
        String message = "";
        String title = "TriangleAreaApp";
        int icon = JOptionPane.PLAIN_MESSAGE;
        //first object to calculate area of triangle with side 2
        TriangleArea obj1 = new TriangleArea(2);
        obj1.computeArea();
        message += obj1.toString();
        //second object to calculate surface area of triangular pyramid with side 2
        PyramidSurfaceArea obj2 = new PyramidSurfaceArea(2);
        obj2.computeSurfaceArea();
        message+=obj2.toString();

        JOptionPane.showMessageDialog(null, message, title, icon);//shows the description of the objects created above.


    }

}