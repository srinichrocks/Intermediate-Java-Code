//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The driver code to display the earnings, overtime pay,
// salary, name and merit pay

public class SeniorWorkerApp {
    public static void main(String[] args) {
        SeniorWorker seniorWorker1 = new SeniorWorker("Bob", 60, 5);//first instance
        System.out.println(seniorWorker1+": "+seniorWorker1.earnings());
        System.out.println("The salary is "+seniorWorker1.salary);
        System.out.println("The overtime pay is: "+ seniorWorker1.overtimePay);
        System.out.println("The merit pay is: "+seniorWorker1.getMeritPay());
    }
}
