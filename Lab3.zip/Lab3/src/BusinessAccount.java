//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The class responsible for determining balance of account
public class BusinessAccount implements Accountable, AccountReceivable{
    private double balance;

    public BusinessAccount(double balance){
        this.balance = balance;
    }

    public void withdraw(double amount){
        this.balance-=amount;
    }
    public double getPayment(){
        return balance;
    }
    public void deposit(double depositAmt) {
        this.balance+=depositAmt;
    }

    @Override
    public String toString() {
        return "Balance is "+balance;
    }
}
