//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The subclasses for triangle and triangular pyramid to determine
//area and surface area respectively
public class TriangleArea extends TriangleDimensions {

    public TriangleArea(double side) {
        super(side);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void computeArea() {
        // TODO Auto-generated method stub
        area = side * side * (Math.sqrt(3)) / 4;

    }
    public void computeSurfaceArea() {
        surfaceArea =side*side*Math.sqrt(3) ;
    }

    @Override
    public String toString() {
        String str = "";
        str += "Shape: " + shape + "\n";
        str += "Side: " + side;
        str += "\nArea: " + area + "\n\n";
        return str;
    }
}
    class PyramidSurfaceArea extends TriangleDimensions {
        public PyramidSurfaceArea(double side){
            super(side);
        }
        public void computeArea() {
            // TODO Auto-generated method stub
            area = side * side * (Math.sqrt(3)) / 4;

        }
        @Override
        public void computeSurfaceArea() {
            surfaceArea =side*side*Math.sqrt(3) ;
        }
        public String toString() {
            String str = "";
            str += "Shape: " + " Triangular Pyramid" + "\n";
            str += "Side: " + side;
            str += "\nSurface Area: " + surfaceArea + "\n\n";
            return str;
        }
    }

