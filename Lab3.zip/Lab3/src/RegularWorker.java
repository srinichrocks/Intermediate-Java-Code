//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: This class is the subclass of employee and super class of senior worker and
//it determines earnings for the regular worker
public class RegularWorker extends Employee {
    protected double salary, overtimePay;

    public RegularWorker( String name, double salary, double overtimePay) {
        super( name );  // call superclass constructor
        this.salary = salary;
        this.overtimePay = overtimePay;
    }


    public double earnings() { return salary + overtimePay; }	//implements the method for polymorphism


    public String toString() {	//override the method to print the name
        return "Regular worker: " + getName();
    }
}

abstract class Employee {
    private String name;

    // Constructor
    public Employee(String name ) {
        this.name = name;
    }

    public String getName()
    { return name; }


    public abstract double earnings();  //define an abstract method for polymorphism
}
