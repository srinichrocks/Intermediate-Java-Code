//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The interface responsible for creating public abstract method
// to deposit payment


public interface AccountReceivable {
    void deposit(double depositAmt);//public abstract
}

