//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: Driver code to display balance
public class BusinessAccountApp {
    public static void main(String[] args) {
        BusinessAccount businessAccount1=new BusinessAccount(50);//first object
        System.out.println("1st: "+businessAccount1);
        businessAccount1.withdraw(10);
        System.out.println("After withdrawl, " + businessAccount1);
        businessAccount1.deposit(13.2);
        System.out.println("After deposit, we have " + businessAccount1.getPayment());


        BusinessAccount businessAccount2=new BusinessAccount(20);//second object
        System.out.println("2nd: "+businessAccount2);
        businessAccount2.withdraw(12.5);
        System.out.println("After withdrawl, " + businessAccount2);
        businessAccount2.deposit(7.6);
        System.out.println("After deposit, we have " + businessAccount2.getPayment());

    }
}
