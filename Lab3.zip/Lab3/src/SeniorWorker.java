//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: This class is the subclass of RegularWorker and determines the earnings
//for the senior worker, which includes meritPay
public class SeniorWorker extends RegularWorker {
    private double meritPay;

    public SeniorWorker(String name, double salary,double overtimePay)
    {
        super(name,salary,overtimePay);

        meritPay=calculateMeritPay();
    }

    public double getMeritPay() {
        return meritPay;
    }

    private double calculateMeritPay(){
        return 0.10 * salary;
    }
    @Override
    public double earnings() { return super.earnings() +calculateMeritPay(); }	//override the method for polymorphism for Manager


    @Override
    public String toString() {	//override the method to print the name
        return "Senior Worker " + super.getName();
    }
}
