//Name: Srinidhi Raghavendran
//Course: CS170-02
//Lab #: Lab 3
//Submission Date: 10:00 pm, Wed (10/23)
//Brief Description: The interface responsible for creating public abstract method to
//withdraw money and get payment

public interface Accountable {
    void withdraw(double amount);
    double getPayment();
}