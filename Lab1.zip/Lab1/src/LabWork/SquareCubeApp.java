/*Raghavendran, Srinidhi
//Intermediate Java Programming
//Course: CS170-02
//Assignment #1
//Generate a table which prints the squares and cubes  of numbers in a table
*/
package LabWork;

public class SquareCubeApp {
  public static void main(String[] args) {
      SquareCube.Operation();
  }
}
