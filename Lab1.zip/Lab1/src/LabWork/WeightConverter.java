/*Raghavendran, Srinidhi
Intermediate Java Programming
Course: CS170-02
Assignment #1
Convert from kilograms to pounds and vice versa. If user enters "n," then program is terminated, otherwise continue with it*/

package LabWork;



public class WeightConverter {
    private static double ktopratio = 2.20462;
    private static double ptokratio = 1 / ktopratio;
    private double value;

    public double K_to_P() {//method to convert from kilos to pounds
        return (value * ktopratio);
    }

    public double P_to_K() {//method to convert from pounds to kilos
        return (value * ptokratio);
    }

    public WeightConverter(double value) {//constructor for WeightConverter class
        this.value = value;
    }
}

