/*Raghavendran, Srinidhi
Intermediate Java Programming
Course: CS170-02
Assignment #1
Generate a table which prints the squares and cubes of numbers in a table. Also has functionality where user can
enter start and end number and table is generated for those respective numbers only*/

package LabWork;

import java.util.Scanner;
public class SquareCube {
    public static void Operation() {
        Scanner scanner=new Scanner(System.in);
        System.out.print("Choose a start integer from 1-10:");//getting user response for what to have as starting number for table
        int beg=scanner.nextInt();
        System.out.print("Choose a end integer from 1-10:");//getting user response for what to have as ending number for table
        int end=scanner.nextInt();
        process(beg,end);//using static method process to generate table from start to end number
        scanner.close();//close scanner to avoid memory loss
    }
    public static void process(int beg, int end) {
        for(int i=beg;i<=end;i++) {
            System.out.printf ("%d        %d        %d\n", i, (i * i), (i * i * i));
        }
    }
}