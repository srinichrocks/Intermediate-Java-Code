/*Raghavendran, Srinidhi
//Intermediate Java Programming
//Course: CS170-02
//Assignment #1
//Convert from kilograms to pounds and vice versa. If user enters "n," then program is terminated
*/

package LabWork;

import java.util.Scanner;
public class WeightConverterApp {
  public static void main(String[] args){
      WeightConverter converter1 = new WeightConverter(5.0);
      System.out.println("First Object Tested");
      System.out.println("Kilograms:"+5.0+" Pounds:"+converter1.K_to_P());//first tested value of part 1 assuming weight entered is in kilos
      System.out.println("Pounds:"+5.0+" Kilograms:"+converter1.P_to_K());//first tested value of part 1 assuming weight entered is in pounds
      WeightConverter converter2 = new WeightConverter(50.);
      System.out.println("Second Object Tested");
      System.out.println("Kilograms:"+50.+" Pounds:"+converter2.K_to_P());//second tested value of part 1 assuming weight entered is in kilos
      System.out.println("Pounds:"+50.+" Kilograms:"+converter2.P_to_K());//second tested value of part 1 assuming weight entered is in pounds

      questionContinuation();//part 2 of lab which asks user if they would like to continue program
  }
  private static void questionContinuation() {
      Scanner scanner = new Scanner(System.in);
      System.out.println("Would you like to continue...y for yes and n for no");//ask user whether he/she would like to continue
      String continuationResponse = scanner.nextLine();
      if (!continuationResponse.equals("n")) {//if user does not enter "n," then continue with the program
          System.out.println("Enter a weight: ");
          double weightResponse = scanner.nextDouble();
          WeightConverter weightConverter = new WeightConverter(weightResponse);
          System.out.println("Pounds:"+weightResponse+"  Kilograms:"+weightConverter.P_to_K());//assuming user entered weight as pounds
          System.out.println("Kilograms:"+weightResponse+"  Pounds:"+weightConverter.K_to_P());//assuming user entered weight as kilos
          scanner.close();
      }
      scanner.close();
      System.exit(0);//if user does enter "n," then immediately terminate program
  }
}


