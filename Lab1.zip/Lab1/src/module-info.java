module Lab1 {
	
}