package lab2;
/*Raghavendran, Srinidhi
 *Intermediate Java Programming
 *Course: CS170-02
 *Assignment #2
 *Calculating return of investment but without UI
 */
import java.util.*;
import java.math.BigDecimal;

public class FutureValueBigDecimalApp {
    public static void main(String ... args) throws InterruptedException {
        System.out.println("\nWelcome to the Future Value Calculator\n");
        Scanner sc = new Scanner(System.in);
        String response ="";
        double monthlyInvestment=0, interestRate=0;
        int years=0;
        while(!response.equalsIgnoreCase("n")){//keep loop going until user enters n
            //prompt
            try
            {
                System.out.print("Enter monthly investment:   ");
                BigDecimal monthlyInvestmentBD = sc.nextBigDecimal();
                if(monthlyInvestmentBD.compareTo(new BigDecimal(1_000_000)) == 1 || monthlyInvestmentBD.compareTo(BigDecimal.ONE) == -1 ) {
                    System.out.println("Invalid Range!\n");
                    continue;
                } else monthlyInvestment = monthlyInvestmentBD.doubleValue();

                System.out.print("Enter yearly interest rate: ");
                BigDecimal interestRateBD = sc.nextBigDecimal();
                interestRateBD.setScale(3,BigDecimal.ROUND_HALF_UP);
                if(interestRateBD.compareTo(new BigDecimal(3.5)) == 1 || monthlyInvestmentBD.compareTo(new BigDecimal(0.1))==-1){
                    System.out.println("Invalid Range!\n");
                    continue;
                } else interestRate = interestRateBD.doubleValue();

                System.out.print("Enter number of years:      ");
                years = sc.nextInt();
                if(years>100 || years<1){
                    System.out.println("Invalid Range!\n");
                    continue;
                }
            }
            catch(InputMismatchException e)
            {
                sc.next(); // discard the incorrectly entered number
                System.out.println("Error! Invalid number. Try again.\n");
                continue;  // jump to the top of the loop
            }

            //Calculate Future Value
            double monthlyInterestRate = FutureValueBigDecimalApp.calculateFutureValue(monthlyInvestment, interestRate, years);
            System.out.println("Future Value:\t" + monthlyInterestRate);

            //End prompt
            boolean validResponse = false;
            do{
                System.out.print("Continue? (y/n): ");
                response = sc.next();

                if (response.equalsIgnoreCase("y") || response.equalsIgnoreCase("n") )
                    validResponse = true;
            } while(!validResponse);

            //decision based on prompt
            if (response.contentEquals("y")) {
                System.out.println();
                continue;
            }

        }

    }

    private static double calculateFutureValue(double monthlyInvestment, double monthlyInterestRate, int years) {
        int months = years*12;
        double futureValue = 0;
        for (int i = 1; i <= months; i++)
            futureValue = (futureValue + monthlyInvestment) *
                    (1 + monthlyInterestRate/12/100);
        return futureValue;
    }
}

