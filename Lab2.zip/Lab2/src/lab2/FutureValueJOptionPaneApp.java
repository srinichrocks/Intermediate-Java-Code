package lab2;
/*Raghavendran, Srinidhi
 *Intermediate Java Programming
 *Course: CS170-02
 *Assignment #2
 *Calculating return of investment with java Swing UI
 */

import javax.swing.*;
import java.math.BigDecimal;



public class FutureValueJOptionPaneApp{
    public static void main(String ... args){
        JOptionPane.showMessageDialog(null, "Welcome to the Future Value Calculator");

        String response ="";
        double monthlyInvestment=0, interestRate=0;
        int years=0;
        while(!response.equalsIgnoreCase("n")){//keep loop going until user enters n
            //prompt
            try
            {
                String monthlyInvestmentUI = JOptionPane.showInputDialog("Enter monthly investment:   ");
                checkIfCancelled(monthlyInvestmentUI);
                BigDecimal monthlyInvestmentBD = new BigDecimal(monthlyInvestmentUI);
                if(monthlyInvestmentBD.compareTo(new BigDecimal(1_000_000)) == 1 || monthlyInvestmentBD.compareTo(BigDecimal.ONE) == -1 ) {
                    JOptionPane.showMessageDialog(null, "Invalid Range!\n");
                    continue;
                } else monthlyInvestment = monthlyInvestmentBD.doubleValue();

                String interestRateUI = JOptionPane.showInputDialog("Enter yearly interest rate: ");
                checkIfCancelled(interestRateUI);
                BigDecimal interestRateBD = new BigDecimal(interestRateUI);
                if(interestRateBD.compareTo(new BigDecimal(3.5)) == 1 || interestRateBD.compareTo(new BigDecimal(0.1))==-1){
                    JOptionPane.showMessageDialog(null, "Invalid Range!\n");
                    continue;
                } else interestRate = interestRateBD.doubleValue();

                String yearUI = JOptionPane.showInputDialog("Enter number of years:      ");
                checkIfCancelled(yearUI);
                years = Integer.valueOf(yearUI);
                if(years>100 || years<1){
                    JOptionPane.showMessageDialog(null, "Invalid Range!\n");
                    continue;
                }
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Error! Invalid number. Try again.\n");
                continue;  // jump to the top of the loop
            }

            //Calculate Future Value
            double monthlyInterestRate = FutureValueJOptionPaneApp.calculateFutureValue(monthlyInvestment, interestRate, years);
            JOptionPane.showMessageDialog(null, "Future Value:\t" + monthlyInterestRate);

            //End prompt
            int endPromptResponse = JOptionPane.showConfirmDialog(null, "Continue?", "Y/N?", JOptionPane.YES_NO_OPTION);
            if (endPromptResponse == 0) continue;
            else if (endPromptResponse == 1) System.exit(0);

        }

    }

    private static double calculateFutureValue(double monthlyInvestment, double monthlyInterestRate, int years) {
        int months = years*12;
        double futureValue = 0;
        for (int i = 1; i <= months; i++)
            futureValue = (futureValue + monthlyInvestment) *
                    (1 + monthlyInterestRate/12/100);
        return futureValue;
    }
    private static void checkIfCancelled(String response){
        if(response==null){
            System.exit(0);
        }
    }
}

