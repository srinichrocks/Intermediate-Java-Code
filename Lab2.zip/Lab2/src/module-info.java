module Lab2 {
	requires java.desktop;
}